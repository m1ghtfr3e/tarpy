.. -*- mode: rst -*-


=====
tarpy
=====

Python CLI application for handling TAR Archives.
Can also be used for making Backups.


Installation
------------

- **using pip**
Install it from PyPi::

    $ python3 -m pip install tarpy

- **On Arch Linux**
There is a AUR package available::
    ...
