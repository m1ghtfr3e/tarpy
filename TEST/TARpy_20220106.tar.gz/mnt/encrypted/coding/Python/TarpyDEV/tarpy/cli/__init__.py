''' CLI Module of Tarpy
'''
